package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.VideoCall
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppScreen
import com.example.ui.AddVideoScreen
import com.example.ui.ChannelDetailViewScreen
import com.example.ui.ChannelsHubScreen
import com.example.ui.FamilyTubeViewModel
import com.example.ui.HomeScreen
import com.example.ui.VideoPlayerScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                FamilyTubeMainApp()
            }
        }
    }
}

@Composable
fun FamilyTubeMainApp(viewModel: FamilyTubeViewModel = viewModel()) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val channels by viewModel.allChannels.collectAsState()
    val videos by viewModel.allVideos.collectAsState()

    // Back handling intercept representing standard device navigation
    val isMainTab = currentScreen is AppScreen.Home || currentScreen is AppScreen.Channels || currentScreen is AppScreen.AddVideo
    BackHandler(enabled = !isMainTab) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // High fidelity material 3 bottom navigation bar
            NavigationBar(
                tonalElevation = 0.dp,
                windowInsets = WindowInsets.navigationBars,
                containerColor = MaterialTheme.colorScheme.background,
                modifier = Modifier
                    .drawBehind {
                        drawLine(
                            color = this.drawContext.canvas.let { Color(0xFF43474E) }, // border color #43474E
                            start = Offset(0f, 0f),
                            end = Offset(size.width, 0f),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                    .testTag("app_bottom_nav_bar")
            ) {
                // Home Feed Tab
                val isHomeSelected = currentScreen is AppScreen.Home || currentScreen is AppScreen.VideoPlayer
                NavigationBarItem(
                    selected = isHomeSelected,
                    onClick = { viewModel.selectTab(AppScreen.Home) },
                    icon = {
                        Icon(
                            imageVector = if (isHomeSelected) Icons.Filled.Home else Icons.Outlined.Home,
                            contentDescription = "Home Feed"
                        )
                    },
                    label = { Text("Family Clips", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.secondary,
                        unselectedIconColor = MaterialTheme.colorScheme.secondary
                    ),
                    modifier = Modifier.testTag("nav_feed_tab")
                )

                // Channels Studio Directory Tab
                val isChannelsSelected = currentScreen is AppScreen.Channels || currentScreen is AppScreen.ChannelDetail
                NavigationBarItem(
                    selected = isChannelsSelected,
                    onClick = { viewModel.selectTab(AppScreen.Channels) },
                    icon = {
                        Icon(
                            imageVector = if (isChannelsSelected) Icons.Filled.People else Icons.Outlined.People,
                            contentDescription = "Studios Hub"
                        )
                    },
                    label = { Text("Studios", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.secondary,
                        unselectedIconColor = MaterialTheme.colorScheme.secondary
                    ),
                    modifier = Modifier.testTag("nav_studios_tab")
                )

                // Share Studio Video Tab
                val isShareSelected = currentScreen is AppScreen.AddVideo
                NavigationBarItem(
                    selected = isShareSelected,
                    onClick = { viewModel.selectTab(AppScreen.AddVideo) },
                    icon = {
                        Icon(
                            imageVector = if (isShareSelected) Icons.Filled.VideoCall else Icons.Outlined.VideoCall,
                            contentDescription = "Share Video"
                        )
                    },
                    label = { Text("Share", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.secondary,
                        unselectedIconColor = MaterialTheme.colorScheme.secondary
                    ),
                    modifier = Modifier.testTag("nav_share_tab")
                )
            }
        }
    ) { innerPadding ->
        // Navigation Controller Switch Router
        val contentModifier = Modifier
            .padding(innerPadding)
            .windowInsetsPadding(WindowInsets.navigationBars)

        when (val screen = currentScreen) {
            is AppScreen.Home -> {
                HomeScreen(
                    viewModel = viewModel,
                    videos = videos,
                    onVideoClick = { id -> viewModel.navigateTo(AppScreen.VideoPlayer(id)) },
                    modifier = contentModifier
                )
            }
            is AppScreen.Channels -> {
                ChannelsHubScreen(
                    viewModel = viewModel,
                    channels = channels,
                    onChannelClick = { id -> viewModel.navigateTo(AppScreen.ChannelDetail(id)) },
                    modifier = contentModifier
                )
            }
            is AppScreen.AddVideo -> {
                AddVideoScreen(
                    viewModel = viewModel,
                    channels = channels,
                    modifier = contentModifier
                )
            }
            is AppScreen.VideoPlayer -> {
                VideoPlayerScreen(
                    viewModel = viewModel,
                    videoId = screen.videoId,
                    onBack = { viewModel.navigateBack() },
                    onChannelClick = { id -> viewModel.navigateTo(AppScreen.ChannelDetail(id)) },
                    modifier = contentModifier
                )
            }
            is AppScreen.ChannelDetail -> {
                ChannelDetailViewScreen(
                    viewModel = viewModel,
                    channelId = screen.channelId,
                    onVideoClick = { id -> viewModel.navigateTo(AppScreen.VideoPlayer(id)) },
                    onBack = { viewModel.navigateBack() },
                    modifier = contentModifier
                )
            }
        }
    }
}
