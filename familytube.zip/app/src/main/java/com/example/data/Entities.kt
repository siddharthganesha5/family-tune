package com.example.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(tableName = "family_channels")
data class FamilyChannel(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val handle: String,
    val description: String,
    val avatarColorOrdinal: Int = 0, // Maps to preset avatar colors or emojis
    val bannerPresetOrdinal: Int = 0, // Maps to preset background banners
    val subCount: Int = 3
)

@Entity(tableName = "family_videos")
data class FamilyVideo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val channelId: Long,
    val title: String,
    val description: String,
    val videoUrl: String, // Mock or simulation URL
    val thumbnailPresetOrdinal: Int = 0, // Maps to a nice visual preset thumbnail
    val duration: String,
    val views: Int = 0,
    val likes: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val category: String = "Vlog"
)

@Entity(tableName = "video_comments")
data class VideoComment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val videoId: Long,
    val authorName: String,
    val authorRole: String = "Family", // e.g., "Dad", "Mom", "Grandma"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class VideoWithChannel(
    @Embedded val video: FamilyVideo,
    @Relation(
        parentColumn = "channelId",
        entityColumn = "id"
    )
    val channel: FamilyChannel
)
