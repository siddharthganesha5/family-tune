package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface FamilyDao {

    @Query("SELECT * FROM family_channels ORDER BY name ASC")
    fun getAllChannels(): Flow<List<FamilyChannel>>

    @Query("SELECT * FROM family_channels WHERE id = :channelId LIMIT 1")
    fun getChannelById(channelId: Long): Flow<FamilyChannel?>

    @Transaction
    @Query("SELECT * FROM family_videos ORDER BY timestamp DESC")
    fun getVideosWithChannels(): Flow<List<VideoWithChannel>>

    @Transaction
    @Query("SELECT * FROM family_videos WHERE channelId = :channelId ORDER BY timestamp DESC")
    fun getVideosByChannel(channelId: Long): Flow<List<VideoWithChannel>>

    @Transaction
    @Query("SELECT * FROM family_videos WHERE id = :videoId LIMIT 1")
    fun getVideoWithChannel(videoId: Long): Flow<VideoWithChannel?>

    @Query("SELECT * FROM video_comments WHERE videoId = :videoId ORDER BY timestamp DESC")
    fun getCommentsForVideo(videoId: Long): Flow<List<VideoComment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannel(channel: FamilyChannel): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideo(video: FamilyVideo): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: VideoComment): Long

    @Query("UPDATE family_videos SET views = views + 1 WHERE id = :videoId")
    suspend fun incrementViews(videoId: Long)

    @Query("UPDATE family_videos SET likes = likes + 1 WHERE id = :videoId")
    suspend fun incrementLikes(videoId: Long)
}
