package com.example.data

import kotlinx.coroutines.flow.Flow

class FamilyRepository(private val familyDao: FamilyDao) {

    val allChannels: Flow<List<FamilyChannel>> = familyDao.getAllChannels()
    val allVideos: Flow<List<VideoWithChannel>> = familyDao.getVideosWithChannels()

    fun getChannelById(channelId: Long): Flow<FamilyChannel?> = familyDao.getChannelById(channelId)

    fun getVideosByChannel(channelId: Long): Flow<List<VideoWithChannel>> = familyDao.getVideosByChannel(channelId)

    fun getVideoWithChannel(videoId: Long): Flow<VideoWithChannel?> = familyDao.getVideoWithChannel(videoId)

    fun getCommentsForVideo(videoId: Long): Flow<List<VideoComment>> = familyDao.getCommentsForVideo(videoId)

    suspend fun insertChannel(channel: FamilyChannel): Long = familyDao.insertChannel(channel)

    suspend fun insertVideo(video: FamilyVideo): Long = familyDao.insertVideo(video)

    suspend fun insertComment(comment: VideoComment): Long = familyDao.insertComment(comment)

    suspend fun incrementViews(videoId: Long) = familyDao.incrementViews(videoId)

    suspend fun incrementLikes(videoId: Long) = familyDao.incrementLikes(videoId)
}
