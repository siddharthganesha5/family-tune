package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FamilyChannel
import com.example.data.FamilyVideo
import com.example.data.VideoComment
import com.example.data.VideoWithChannel
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sin

// --- RENDER PRESET THUMBNAILS WITH ARTISTIC GRADIENTS ---
@Composable
fun VideoThumbnail(
    presetOrdinal: Int,
    duration: String,
    modifier: Modifier = Modifier
) {
    val brush = remember(presetOrdinal) {
        when (presetOrdinal) {
            0 -> Brush.linearGradient(colors = listOf(Color(0xFFE65100), Color(0xFFFFB74D))) // BBQ
            1 -> Brush.linearGradient(colors = listOf(Color(0xFFAD1457), Color(0xFFF06292))) // Paste Lab
            2 -> Brush.linearGradient(colors = listOf(Color(0xFF1B5E20), Color(0xFF81C784))) // Yosemetie
            3 -> Brush.linearGradient(colors = listOf(Color(0xFF0D47A1), Color(0xFF64B5F6))) // Legos
            4 -> Brush.linearGradient(colors = listOf(Color(0xFF006064), Color(0xFF4DD0E1))) // Green Garden
            else -> Brush.radialGradient(colors = listOf(Color(0xFF6A1B9A), Color(0xFFBA68C8))) // Default
        }
    }

    val emoji = remember(presetOrdinal) {
        when (presetOrdinal) {
            0 -> "🍖🔥🍢"
            1 -> "🍪🍞🧁"
            2 -> "🌲⛰️🥾"
            3 -> "🧱🏰🤖"
            4 -> "🌿🪴🌻"
            else -> "📸⛅🎬"
        }
    }

    val subtitle = remember(presetOrdinal) {
        when (presetOrdinal) {
            0 -> "Backyard Grill"
            1 -> "Fresh Baked"
            2 -> "Nature Vlog"
            3 -> "LEGO Build"
            4 -> "Botanical Care"
            else -> "Family Shared"
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(brush)
    ) {
        // Overlay visual lines/patterns for tech realism
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = size.height / 6f
            for (i in 1..5) {
                drawLine(
                    color = Color.White.copy(alpha = 0.08f),
                    start = Offset(0f, i * step),
                    end = Offset(size.width, i * step),
                    strokeWidth = 2f
                )
            }
        }

        // Center Content Emojis & label
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = emoji,
                fontSize = 32.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                color = Color.Black.copy(alpha = 0.35f),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = subtitle,
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        // Bottom Right Duration
        Surface(
            color = Color.Black.copy(alpha = 0.8f),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
        ) {
            Text(
                text = duration,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

// --- RENDERING CHANNELS AVATARS ---
@Composable
fun ChannelAvatar(
    colorOrdinal: Int,
    name: String,
    sizeDp: Int = 40,
    fontSizeSp: Int = 16
) {
    val color = remember(colorOrdinal) {
        when (colorOrdinal) {
            0 -> AvatarOrange
            1 -> AvatarPink
            2 -> AvatarTeal
            3 -> AvatarGreen
            4 -> AvatarIndigo
            else -> PrimaryRed
        }
    }
    val initials = name.firstOrNull()?.toString()?.uppercase() ?: "F"

    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(CircleShape)
            .background(color),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initials,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = fontSizeSp.sp
        )
    }
}

// --- UTILITY FORMAT DATE ---
fun formatRelativeDate(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    val hours = diff / (3600 * 1000)
    return when {
         hours < 1 -> "Just now"
         hours < 24 -> "${hours}h ago"
         else -> "${hours / 24}d ago"
    }
}

// ==========================================
// 1. HOME SCREEN FEED (All items list)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: FamilyTubeViewModel,
    videos: List<VideoWithChannel>,
    onVideoClick: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()

    val categories = listOf("All", "Cooking", "Hobbies", "Travel")

    // Dynamic Filter & Search
    val filteredVideos = remember(videos, searchQuery, selectedCategory) {
        videos.filter { item ->
            val matchesQuery = item.video.title.contains(searchQuery, ignoreCase = true) ||
                    item.channel.name.contains(searchQuery, ignoreCase = true)
            val matchesCategory = selectedCategory == "All" || item.video.category.equals(selectedCategory, ignoreCase = true)
            matchesQuery && matchesCategory
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_content")
    ) {
        // App header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.PlayArrow,
                contentDescription = "Logo",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                    .padding(4.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "FamilyTube",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Private Family Broadcaster",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Search Bar (Polished & Rounded)
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.updateSearchQuery(it) },
            placeholder = { Text("Search shared family clips...", fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear search")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.12f),
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("search_bar_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Category Selection
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categories) { category ->
                val isSelected = category == selectedCategory
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectCategory(category) },
                    label = { Text(category, fontWeight = FontWeight.SemiBold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                        containerColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.05f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = null,
                    modifier = Modifier.testTag("category_chip_${category.lowercase()}")
                )
            }
        }

        // Active Channels (from Elegant Dark Design HTML specs)
        val channelsList by viewModel.allChannels.collectAsState()
        if (channelsList.isNotEmpty()) {
            Spacer(modifier = Modifier.height(14.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ACTIVE CHANNELS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "See all",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            viewModel.selectTab(AppScreen.Channels)
                        }
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(channelsList) { studio ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable {
                                    viewModel.navigateTo(AppScreen.ChannelDetail(studio.id))
                                }
                        ) {
                            val avatarColor = remember(studio.avatarColorOrdinal) {
                                when (studio.avatarColorOrdinal) {
                                    0 -> AvatarOrange
                                    1 -> AvatarPink
                                    2 -> AvatarTeal
                                    3 -> AvatarGreen
                                    4 -> AvatarIndigo
                                    else -> PrimaryRed
                                }
                            }
                            // Ring offset visual styling from HTML design specification
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                    .padding(3.dp)
                                    .clip(CircleShape)
                                    .background(avatarColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = studio.name.firstOrNull()?.toString()?.uppercase() ?: "F",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = studio.name.split(" ").firstOrNull() ?: studio.name,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Video Feed List or Empty placeholder
        if (filteredVideos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FilterNone,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No shared family clips here yet",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Try clearing queries, picking 'All' or tapping Share!",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("videos_lazy_column")
            ) {
                items(filteredVideos, key = { it.video.id }) { item ->
                    VideoFeedItemCard(item = item, onClick = { onVideoClick(item.video.id) })
                }
            }
        }
    }
}

@Composable
fun VideoFeedItemCard(
    item: VideoWithChannel,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable(onClick = onClick)
            .testTag("video_item_${item.video.id}"),
        shape = RoundedCornerShape(24.dp), // Elegant modern curved corners matching Design HTML
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            // Video Thumbnail Frame
            VideoThumbnail(
                presetOrdinal = item.video.thumbnailPresetOrdinal,
                duration = item.video.duration,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            )

            // Info Details Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                ChannelAvatar(
                    colorOrdinal = item.channel.avatarColorOrdinal,
                    name = item.channel.name,
                    sizeDp = 40
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.video.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = item.channel.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "•",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f)
                        )
                        Text(
                            text = formatRelativeDate(item.video.timestamp),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                        Text(
                            text = "•",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f)
                        )
                        Text(
                            text = "${item.video.views} views",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 2. VIDEO PLAYER SCREEN (Interactive Simulation)
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoPlayerScreen(
    viewModel: FamilyTubeViewModel,
    videoId: Long,
    onBack: () -> Unit,
    onChannelClick: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val playingVideoWithChannel by viewModel.playingVideo.collectAsState()
    val comments by viewModel.currentVideoComments.collectAsState()

    var isPlaying by remember { mutableStateOf(true) }
    var userSliderProgress by remember { mutableStateOf<Float?>(null) }
    var isMuted by remember { mutableStateOf(false) }

    // Waveform simulation properties
    val infiniteTransition = rememberInfiniteTransition(label = "audio_visualizer")
    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "offset"
    )

    // Translate duration string "MM:SS" back to total seconds integer
    val videoWithChannel = playingVideoWithChannel ?: return
    val totalSeconds = remember(videoWithChannel.video.duration) {
        val parts = videoWithChannel.video.duration.split(":")
        val minutes = parts.getOrNull(0)?.toIntOrNull() ?: 5
        val seconds = parts.getOrNull(1)?.toIntOrNull() ?: 0
        minutes * 60 + seconds
    }

    // Playback Timeline ticker
    var currentSecondsSec by remember { mutableStateOf(0) }
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (true) {
                delay(1000)
                currentSecondsSec = (currentSecondsSec + 1) % (totalSeconds + 1)
                if (currentSecondsSec == 0) {
                    isPlaying = false
                }
            }
        }
    }

    val displaySeconds = userSliderProgress?.let { (it * totalSeconds).toInt() } ?: currentSecondsSec
    val progressRatio = displaySeconds.toFloat() / totalSeconds.toFloat()

    // Form states for posting high-tactile reviews
    val channelsList by viewModel.allChannels.collectAsState()
    var selectedCommenterIndex by remember { mutableStateOf(0) }
    var currentCommentText by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("video_player_root")
    ) {
        // Back Navigation bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("player_back_button")) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Playing Shared Video",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // --- THE FULLY INTERACTIVE CINEMATIC VIDEO PLAYER CANVAS ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(Color.Black)
                .testTag("interactive_canvas_player")
        ) {
            // Visual Waveform Animation based on thumbnail Preset colors if playing
            val presetColor = remember(videoWithChannel.video.thumbnailPresetOrdinal) {
                when (videoWithChannel.video.thumbnailPresetOrdinal) {
                    0 -> Color(0xFFE53935)
                    1 -> Color(0xFFD81B60)
                    2 -> Color(0xFF43A047)
                    3 -> Color(0xFF1E88E5)
                    4 -> Color(0xFF00ACC1)
                    else -> Color(0xFF8E24AA)
                }
            }

            Canvas(modifier = Modifier.fillMaxSize()) {
                val midY = size.height / 2f
                val width = size.width
                val waveCount = 3
                val amplitude = if (isPlaying) 40f else 8f

                // Draw background design
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(presetColor.copy(alpha = 0.25f), Color.Transparent),
                        center = Offset(width / 2f, midY),
                        radius = size.width * 0.8f
                    )
                )

                // Render customized trigonometric wave loops representing dynamic movement
                for (waveIndex in 0 until waveCount) {
                    val alphaRatio = 1f - (waveIndex * 0.25f)
                    val strokeW = 4f - waveIndex
                    val densityMod = 1f + (waveIndex * 0.5f)

                    val pathPoints = mutableListOf<Offset>()
                    for (x in 0..width.toInt() step 5) {
                        val angle = (x / width) * 2f * Math.PI.toFloat() * densityMod + waveOffset
                        val y = midY + sin(angle) * amplitude
                        pathPoints.add(Offset(x.toFloat(), y))
                    }

                    for (i in 0 until pathPoints.size - 1) {
                        drawLine(
                            color = presetColor.copy(alpha = alphaRatio),
                            start = pathPoints[i],
                            end = pathPoints[i + 1],
                            strokeWidth = strokeW,
                            cap = androidx.compose.ui.graphics.StrokeCap.Round
                        )
                    }
                }

                // Render central overlay badge if paused
                if (!isPlaying) {
                    drawCircle(
                        color = Color.Black.copy(alpha = 0.6f),
                        radius = 45f,
                        center = Offset(width / 2f, midY)
                    )
                }
            }

            // Central Pause / Play overlay sign
            if (!isPlaying) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier
                        .size(48.dp)
                        .align(Alignment.Center)
                )
            }

            // Bottom Player Information banner & Interactive controls in card overlay
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f))))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                // Interactive slider
                Slider(
                    value = progressRatio,
                    onValueChange = { scale ->
                        userSliderProgress = scale
                    },
                    onValueChangeFinished = {
                        userSliderProgress?.let {
                            currentSecondsSec = (it * totalSeconds).toInt()
                        }
                        userSliderProgress = null
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = Color.Red,
                        activeTrackColor = Color.Red,
                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier
                        .height(28.dp)
                        .testTag("player_progress_slider")
                )

                // Control panel
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Playback time indicator
                    val m1 = displaySeconds / 60
                    val s1 = displaySeconds % 60
                    val m2 = totalSeconds / 60
                    val s2 = totalSeconds % 60
                    Text(
                        text = String.format("%02d:%02d / %02d:%02d", m1, s1, m2, s2),
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 4.dp)
                    )

                    // Core media control buttons
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { currentSecondsSec = maxOf(0, currentSecondsSec - 10) }) {
                            Icon(Icons.Filled.Replay10, contentDescription = "-10 seconds", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        IconButton(
                            onClick = { isPlaying = !isPlaying },
                            modifier = Modifier.testTag("action_toggle_playback")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause toggle",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        IconButton(onClick = { currentSecondsSec = minOf(totalSeconds, currentSecondsSec + 10) }) {
                            Icon(Icons.Filled.Forward10, contentDescription = "+10 seconds", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }

                    // Mute control
                    IconButton(onClick = { isMuted = !isMuted }) {
                        Icon(
                            imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                            contentDescription = "Mute",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // SCROLLABLE BODY SCREEN FOR META INFO AND COMMENT THREADS
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("comments_and_details_lazy_column"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Title & View stats
            item {
                Column {
                    Text(
                        text = videoWithChannel.video.title,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${videoWithChannel.video.views} views",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                        Text(
                            text = " • ",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                        )
                        Text(
                            text = formatRelativeDate(videoWithChannel.video.timestamp),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    }
                }
            }

            // Immediate Action items (Like, Share)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { viewModel.addLike(videoId) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("button_like_video")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Favorite, contentDescription = "Like")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("${videoWithChannel.video.likes} Likes", fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedButton(
                        onClick = { /* Simulated native share dialogue to SMS family */ },
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Family Share", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Channel Publisher Header
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.03f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onChannelClick(videoWithChannel.channel.id) }
                        .testTag("author_channel_box")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ChannelAvatar(
                            colorOrdinal = videoWithChannel.channel.avatarColorOrdinal,
                            name = videoWithChannel.channel.name,
                            sizeDp = 42
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = videoWithChannel.channel.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${videoWithChannel.channel.handle} • ${videoWithChannel.channel.subCount} followers",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "View Channel",
                            tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                        )
                    }
                }
            }

            // Description details foldout
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.onBackground.copy(alpha = 0.03f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(12.dp)
                ) {
                    Text(
                        text = "Description",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = videoWithChannel.video.description,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f)
                    )
                }
            }

            // Comments bar Title
            item {
                Text(
                    text = "Relative Discussions (${comments.size})",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // New Comment Posting Form (Multi-User selection logic)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Which family member is posting?",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        // Left scrolling avatar selection row
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            itemsIndexed(channelsList) { index, member ->
                                val isSelected = index == selectedCommenterIndex
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(
                                            if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                            else Color.Transparent
                                        )
                                        .border(
                                            width = 1.5.dp,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(20.dp)
                                        )
                                        .clickable { selectedCommenterIndex = index }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        ChannelAvatar(
                                            colorOrdinal = member.avatarColorOrdinal,
                                            name = member.name,
                                            sizeDp = 20,
                                            fontSizeSp = 9
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = member.name.split(" ").firstOrNull() ?: member.name,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Text typing frame
                        OutlinedTextField(
                            value = currentCommentText,
                            onValueChange = { currentCommentText = it },
                            placeholder = { Text("Add supportive comments for dinner...", fontSize = 13.sp) },
                            singleLine = false,
                            maxLines = 3,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("comment_input_box"),
                            textStyle = TextStyle(fontSize = 13.sp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f)
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = {
                                    val member = channelsList.getOrNull(selectedCommenterIndex)
                                    if (member != null && currentCommentText.isNotBlank()) {
                                        viewModel.postComment(
                                            videoId = videoId,
                                            authorName = member.name,
                                            authorRole = member.handle,
                                            content = currentCommentText
                                        )
                                        currentCommentText = ""
                                        focusManager.clearFocus()
                                    }
                                },
                                shape = RoundedCornerShape(16.dp),
                                enabled = currentCommentText.isNotBlank(),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("comment_post_btn")
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Post Share", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Scrolling Comment list items
            if (comments.isEmpty()) {
                item {
                    Text(
                        text = "No comments on this shared clip yet. Be the first to tell Dad his smoking rules!",
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    )
                }
            } else {
                items(comments, key = { it.id }) { comment ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Dynamic find member matching color config
                                val matchedUser = channelsList.find { it.name == comment.authorName }
                                ChannelAvatar(
                                    colorOrdinal = matchedUser?.avatarColorOrdinal ?: 4,
                                    name = comment.authorName,
                                    sizeDp = 28,
                                    fontSizeSp = 11
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = comment.authorName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Surface(
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = if (comment.authorRole.startsWith("@")) comment.authorRole else "@${comment.authorRole.lowercase()}",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = formatRelativeDate(comment.timestamp),
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = comment.content,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f),
                                modifier = Modifier.padding(start = 36.dp)
                            )
                        }
                    }
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.04f),
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }
    }
}

// ==========================================
// 3. CHANNELS HUB SCREEN (Browse & Create Channels)
// ==========================================
@Composable
fun ChannelsHubScreen(
    viewModel: FamilyTubeViewModel,
    channels: List<FamilyChannel>,
    onChannelClick: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateChannelDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("channels_hub_root")
    ) {
        // Hub Banner title
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Family Creators",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Broadcasting studios of the relatives",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Create new studio button
            FloatingActionButton(
                onClick = { showCreateChannelDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .size(42.dp)
                    .testTag("btn_add_new_channel")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add Family Member Studio")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Grid listing of channels
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("channels_lazy_list")
        ) {
            items(channels, key = { it.id }) { studio ->
                ChannelItemRowCard(studio = studio, onClick = { onChannelClick(studio.id) })
            }
        }
    }

    if (showCreateChannelDialog) {
        CreateChannelDialog(
            onDismiss = { showCreateChannelDialog = false },
            onSubmit = { name, handle, description, colorOrd ->
                viewModel.createChannel(name, handle, description, colorOrd)
                showCreateChannelDialog = false
            }
        )
    }
}

@Composable
fun ChannelItemRowCard(
    studio: FamilyChannel,
    onClick: () -> Unit
) {
    val bannerBrush = remember(studio.bannerPresetOrdinal) {
        when (studio.bannerPresetOrdinal) {
            0 -> Brush.horizontalGradient(listOf(BannerPreset1, Color(0xFF9C27B0)))
            1 -> Brush.horizontalGradient(listOf(BannerPreset2, Color(0xFF3F51B5)))
            2 -> Brush.horizontalGradient(listOf(BannerPreset3, Color(0xFF009688)))
            3 -> Brush.horizontalGradient(listOf(BannerPreset4, Color(0xFF4CAF50)))
            else -> Brush.horizontalGradient(listOf(BannerPreset5, Color(0xFFFF9800)))
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("channel_card_${studio.id}"),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.05f)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Upper Mini colored banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(bannerBrush)
            )

            // Dynamic bottom area offset details
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ChannelAvatar(
                    colorOrdinal = studio.avatarColorOrdinal,
                    name = studio.name,
                    sizeDp = 48,
                    fontSizeSp = 20
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = studio.name,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${studio.handle} • ${studio.subCount} followers",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    modifier = Modifier.size(20.dp)
                )
            }

            // Description summary
            if (studio.description.isNotBlank()) {
                Text(
                    text = studio.description,
                    fontSize = 12.sp,
                    maxLines = 2,
                    lineHeight = 16.sp,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    modifier = Modifier.padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
                )
            }
        }
    }
}

// Dialog screen popup for adding a studio
@Composable
fun CreateChannelDialog(
    onDismiss: () -> Unit,
    onSubmit: (String, String, String, Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var handle by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var colorOrdinal by remember { mutableStateOf(0) }

    val colorOptions = listOf(
        AvatarOrange, AvatarPink, AvatarTeal, AvatarGreen, AvatarIndigo
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Launch Family Channel", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Set up a broadcasting channel. Family members will see this and can play your uploaded feeds.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Channel Name (e.g., Uncle John)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("field_channel_name")
                )

                OutlinedTextField(
                    value = handle,
                    onValueChange = { handle = it },
                    label = { Text("Handle (e.g. @john_woodwork)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("field_channel_handle")
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Studio Bio (e.g. Backyard projects)") },
                    singleLine = false,
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Column {
                    Text(
                        text = "Choose Badge Color",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        colorOptions.forEachIndexed { idx, col ->
                            val isSelected = idx == colorOrdinal
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(col)
                                    .border(
                                        width = if (isSelected) 3.dp else 0.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .clickable { colorOrdinal = idx }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && handle.isNotBlank()) {
                        onSubmit(name, handle, description, colorOrdinal)
                    }
                },
                enabled = name.isNotBlank() && handle.isNotBlank(),
                modifier = Modifier.testTag("btn_submit_channel")
            ) {
                Text("Launch Studio")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// ==========================================
// 4. CHANNEL DETAIL VIEW SCREEN
// ==========================================
@Composable
fun ChannelDetailViewScreen(
    viewModel: FamilyTubeViewModel,
    channelId: Long,
    onVideoClick: (Long) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val channelFlow = remember(channelId) { viewModel.getChannelFlow(channelId) }
    val channel by channelFlow.collectAsState()

    val videosFlow = remember(channelId) { viewModel.getVideosForChannel(channelId) }
    val videos by videosFlow.collectAsState()

    val activeChannel = channel ?: return

    val bannerBrush = remember(activeChannel.bannerPresetOrdinal) {
        when (activeChannel.bannerPresetOrdinal) {
            0 -> Brush.horizontalGradient(listOf(BannerPreset1, Color(0xFF9C27B0)))
            1 -> Brush.horizontalGradient(listOf(BannerPreset2, Color(0xFF3F51B5)))
            2 -> Brush.horizontalGradient(listOf(BannerPreset3, Color(0xFF009688)))
            3 -> Brush.horizontalGradient(listOf(BannerPreset4, Color(0xFF4CAF50)))
            else -> Brush.horizontalGradient(listOf(BannerPreset5, Color(0xFFFF9800)))
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("channel_detail_root")
    ) {
        // Simple Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("detail_back_button")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "${activeChannel.name}'s Channel",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth().weight(1f)
        ) {
            // Master Banner Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .background(bannerBrush),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f))))
                    )
                    Text(
                        text = "FAMILY BROADCAST",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(16.dp).align(Alignment.TopEnd)
                    )
                }
            }

            // Studio Meta Header Info
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ChannelAvatar(
                        colorOrdinal = activeChannel.avatarColorOrdinal,
                        name = activeChannel.name,
                        sizeDp = 64,
                        fontSizeSp = 24
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = activeChannel.name,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "${activeChannel.handle} • ${activeChannel.subCount} Subscribers",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Description summary
            if (activeChannel.description.isNotBlank()) {
                item {
                    Text(
                        text = activeChannel.description,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    )
                }
            }

            item {
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f),
                    thickness = 1.dp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            // Section Banner clip
            item {
                Text(
                    text = "Shared Streams (${videos.size})",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp)
                )
            }

            // Uploaded videos feed belonging strictly to them
            if (videos.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudQueue,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No shared videos under this studio",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Tap on 'Share' tab to add a video for ${activeChannel.name}!",
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.35f),
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                items(videos, key = { it.video.id }) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onVideoClick(item.video.id) }
                            .padding(horizontal = 16.dp)
                            .testTag("channel_video_item_${item.video.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.02f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.04f))
                    ) {
                        Row(modifier = Modifier.padding(8.dp)) {
                            VideoThumbnail(
                                presetOrdinal = item.video.thumbnailPresetOrdinal,
                                duration = item.video.duration,
                                modifier = Modifier
                                    .size(width = 110.dp, height = 75.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.video.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row {
                                    Text(
                                        text = "${item.video.views} views",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = " • ",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                                    )
                                    Text(
                                        text = formatRelativeDate(item.video.timestamp),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. UPLOAD / PUBLISH VIDEO SCREEN (Form)
// ==========================================
@Composable
fun AddVideoScreen(
    viewModel: FamilyTubeViewModel,
    channels: List<FamilyChannel>,
    modifier: Modifier = Modifier
) {
    if (channels.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Please create a family channel in the 'Channels' tab first before publishing!",
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
        return
    }

    var selectedChannelIndex by remember { mutableStateOf(0) }
    var selectedChannelDropdownOpen by remember { mutableStateOf(false) }

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("03:30") }
    var category by remember { mutableStateOf("Vlog") }
    var thumbnailPreset by remember { mutableStateOf(0) }

    val categories = listOf("Vlog", "Cooking", "Hobbies", "Travel")
    val currentChannel = channels.getOrNull(selectedChannelIndex) ?: channels[0]

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier
            .fillMaxSize()
            .testTag("add_video_form_root")
    ) {
        // Upper Intro Callout
        item {
            Column {
                Text(
                    text = "Share Family Video",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Publish a video to your family member channel",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Channel selector dropdown
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Select Publishing Channel",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.onBackground.copy(alpha = 0.04f))
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.onBackground.copy(alpha = 0.08f),
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { selectedChannelDropdownOpen = true }
                        .padding(12.dp)
                        .testTag("field_select_author_channel")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ChannelAvatar(
                                colorOrdinal = currentChannel.avatarColorOrdinal,
                                name = currentChannel.name,
                                sizeDp = 28,
                                fontSizeSp = 11
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = currentChannel.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = currentChannel.handle,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Icon(
                            imageVector = if (selectedChannelDropdownOpen) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                            contentDescription = null
                        )
                    }

                    DropdownMenu(
                        expanded = selectedChannelDropdownOpen,
                        onDismissRequest = { selectedChannelDropdownOpen = false },
                        modifier = Modifier.fillMaxWidth(0.85f)
                    ) {
                        channels.forEachIndexed { idx, item ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        ChannelAvatar(
                                            colorOrdinal = item.avatarColorOrdinal,
                                            name = item.name,
                                            sizeDp = 24,
                                            fontSizeSp = 9
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("${item.name} (${item.handle})", fontSize = 13.sp)
                                    }
                                },
                                onClick = {
                                    selectedChannelIndex = idx
                                    selectedChannelDropdownOpen = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Title box input
        item {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Video Title (e.g. Grandma's 80th Birthday)") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("field_video_title"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f)
                )
            )
        }

        // Details biography description input
        item {
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("What is this shared video about?") },
                singleLine = false,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("field_video_desc"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f)
                )
            )
        }

        // Row of Duration & Category selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = duration,
                    onValueChange = { duration = it },
                    label = { Text("Duration") },
                    placeholder = { Text("03:45") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f)
                    )
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Category",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    var catDropdownOpen by remember { mutableStateOf(false) }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f),
                                RoundedCornerShape(4.dp)
                            )
                            .clickable { catDropdownOpen = true }
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(category, fontSize = 14.sp)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }

                        DropdownMenu(
                            expanded = catDropdownOpen,
                            onDismissRequest = { catDropdownOpen = false }
                        ) {
                            categories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        category = cat
                                        catDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Thumbnail Preset Selector
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Select Thumbnail Illustration Style",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(5) { id ->
                        val isSelected = id == thumbnailPreset
                        Box(
                            modifier = Modifier
                                .clickable { thumbnailPreset = id }
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .padding(2.dp)
                        ) {
                            VideoThumbnail(
                                presetOrdinal = id,
                                duration = duration,
                                modifier = Modifier.size(width = 120.dp, height = 80.dp)
                            )
                        }
                    }
                }
            }
        }

        // Big Submit Share button
        item {
            Button(
                onClick = {
                    if (title.isNotBlank() && description.isNotBlank()) {
                        viewModel.uploadVideo(
                            channelId = currentChannel.id,
                            title = title,
                            description = description,
                            duration = duration,
                            category = category,
                            thumbnailPresetOrdinal = thumbnailPreset
                        )
                    }
                },
                shape = RoundedCornerShape(12.dp),
                enabled = title.isNotBlank() && description.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_publish_shared_video")
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Publish to Family Feed", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }

        // Safety spacing margin for scrolling
        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
