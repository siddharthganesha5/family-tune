package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.FamilyChannel
import com.example.data.FamilyRepository
import com.example.data.FamilyVideo
import com.example.data.VideoComment
import com.example.data.VideoWithChannel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface AppScreen {
    object Home : AppScreen
    object Channels : AppScreen
    object AddVideo : AppScreen
    data class VideoPlayer(val videoId: Long) : AppScreen
    data class ChannelDetail(val channelId: Long) : AppScreen
}

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class FamilyTubeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FamilyRepository
    
    // Bottom tab integration / navigation backstack
    private val _currentScreen = MutableStateFlow<AppScreen>(AppScreen.Home)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val screenBackstack = mutableListOf<AppScreen>()

    // Search query on Home Feed
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Sub-category of videos (All, cooking, Hobbies, travel, kids)
    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // Database Flows
    val allChannels: StateFlow<List<FamilyChannel>>
    val allVideos: StateFlow<List<VideoWithChannel>>

    // When playing a video, state holds it
    private val _playingVideoId = MutableStateFlow<Long?>(null)
    
    val playingVideo: StateFlow<VideoWithChannel?> = _playingVideoId
        .flatMapLatest { videoId ->
            if (videoId != null) {
                repository.getVideoWithChannel(videoId)
            } else {
                MutableStateFlow(null)
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val currentVideoComments: StateFlow<List<VideoComment>> = _playingVideoId
        .flatMapLatest { videoId ->
            if (videoId != null) {
                repository.getCommentsForVideo(videoId)
            } else {
                MutableStateFlow(emptyList())
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        val database = AppDatabase.getDatabase(application)
        repository = FamilyRepository(database.familyDao())

        // Collect streams
        allChannels = repository.allChannels.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allVideos = repository.allVideos.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Preseed if DB empty
        viewModelScope.launch {
            checkAndSeedDatabase()
        }
    }

    private suspend fun checkAndSeedDatabase() {
        // We look up all channels, wait briefly for emissions or fetch them.
        allChannels.collect { channels ->
            if (channels.isEmpty()) {
                seedInitialDatabase()
            }
        }
    }

    private suspend fun seedInitialDatabase() {
        // 1. Create family channels
        val dadId = repository.insertChannel(
            FamilyChannel(
                name = "Dad's Backyard Barbecue",
                handle = "@dad_cooks",
                description = "Authentic smoky ribs, garden builds, and secret steak recipes. Welcome to family grill central!",
                avatarColorOrdinal = 0, // Orange-Red
                bannerPresetOrdinal = 0,
                subCount = 12
            )
        )

        val momId = repository.insertChannel(
            FamilyChannel(
                name = "Mom's Pastry & Bake Lab",
                handle = "@mom_bakes",
                description = "Baking sweet moments! Sharing sourdough wisdom, holiday cookie tins, and cozy home kitchen recipes.",
                avatarColorOrdinal = 1, // Rose Gold
                bannerPresetOrdinal = 1,
                subCount = 18
            )
        )

        val claraId = repository.insertChannel(
            FamilyChannel(
                name = "Cousin Clara's Vlogs",
                handle = "@clara_ventures",
                description = "Weekend wilderness camping roadtrips and study-abroad letters. Capturing memories for the relatives!",
                avatarColorOrdinal = 2, // Emerald
                bannerPresetOrdinal = 2,
                subCount = 9
            )
        )

        val tommyId = repository.insertChannel(
            FamilyChannel(
                name = "Tommy's Brick & Lego Vault",
                handle = "@tommy_blocks",
                description = "Unboxing, custom castle setups, and speed builds of giant LEGO fortresses! Watch out for steps!",
                avatarColorOrdinal = 3, // Blue-Indigo
                bannerPresetOrdinal = 3,
                subCount = 21
            )
        )

        val sarahId = repository.insertChannel(
            FamilyChannel(
                name = "Aunt Sarah's Urban Patch",
                handle = "@sarah_gardener",
                description = "Cozy gardening hacks, flower garden propagation tips, and microgreen grow schedules.",
                avatarColorOrdinal = 4, // Teal Green
                bannerPresetOrdinal = 4,
                subCount = 7
            )
        )

        // 2. Preseed corresponding high-quality family videos
        val v1 = repository.insertVideo(
            FamilyVideo(
                channelId = dadId,
                title = "Dad's Backyard Ribs 3-2-1 Guide!",
                description = "Sharing my complete walkthrough for the perfect smoked ribs. Super tender, sweet glaze, and guaranteed to blow your uncles away! Try it this Sunday.",
                videoUrl = "https://example.com/videos/ribs.mp4",
                thumbnailPresetOrdinal = 0, // BBQ
                duration = "14:20",
                views = 48,
                likes = 18,
                timestamp = System.currentTimeMillis() - 86400000 * 2, // 2 days ago
                category = "Cooking"
            )
        )

        val v2 = repository.insertVideo(
            FamilyVideo(
                channelId = momId,
                title = "Holiday Gingerbread Cookies!",
                description = "The secret is adding a pinch of white pepper and allowing the spice dough to sit overnight. Join me to make delicious reindeer biscuits with our family design template!",
                videoUrl = "https://example.com/videos/cookies.mp4",
                thumbnailPresetOrdinal = 1, // Pastries
                duration = "08:15",
                views = 76,
                likes = 32,
                timestamp = System.currentTimeMillis() - 86400000 * 1, // 1 day ago
                category = "Cooking"
            )
        )

        val v3 = repository.insertVideo(
            FamilyVideo(
                channelId = claraId,
                title = "Exploring Yosemite Valley Cabin",
                description = "A rainy weekend in Yosemite. We explored Bridalveil Falls and did some drawing. Enjoy the slow crackly fireplace scenes at the end!",
                videoUrl = "https://example.com/videos/yosemite.mp4",
                thumbnailPresetOrdinal = 2, // Nature
                duration = "11:42",
                views = 125,
                likes = 54,
                timestamp = System.currentTimeMillis() - 3600000 * 8, // 8 hours ago
                category = "Travel"
            )
        )

        val v4 = repository.insertVideo(
            FamilyVideo(
                channelId = tommyId,
                title = "Stop Motion LEGO Castle Battle!!",
                description = "Finished building the Royal Lion Stronghold! Took 400 photos to animate this epic castle breach. Let me know which knight was your favorite!",
                videoUrl = "https://example.com/videos/lego.mp4",
                thumbnailPresetOrdinal = 3, // Toys
                duration = "03:10",
                views = 96,
                likes = 45,
                timestamp = System.currentTimeMillis() - 3600000 * 2, // 2 hours ago
                category = "Hobbies"
            )
        )

        val v5 = repository.insertVideo(
            FamilyVideo(
                channelId = sarahId,
                title = "Indoor Propagation Routine",
                description = "Don't throw away leggy Monstera! I will show you how to safely slice, store in water glass jar, and observe roots in 14 days.",
                videoUrl = "https://example.com/videos/propagation.mp4",
                thumbnailPresetOrdinal = 4, // Plants
                duration = "05:52",
                views = 31,
                likes = 14,
                timestamp = System.currentTimeMillis() - 86400000 * 4, // 4 days ago
                category = "Hobbies"
            )
        )

        // 3. Preseed friendly family comments so discussions feel alive!
        repository.insertComment(
            VideoComment(videoId = v1, authorName = "Aunt Sarah", authorRole = "Aunt", content = "Dad, are you bringing these to the family reunion? They look absolutely incredible!")
        )
        repository.insertComment(
            VideoComment(videoId = v1, authorName = "Cousin Clara", authorRole = "Cousin", content = "Tried this on my small charcoal grill. The 3h smoke period was a game changer!")
        )

        repository.insertComment(
            VideoComment(videoId = v2, authorName = "Tommy", authorRole = "Cousin", content = "Can we paint the noses red again this year? Red icing rocks!")
        )

        repository.insertComment(
            VideoComment(videoId = v3, authorName = "Dad", authorRole = "Uncle", content = "Gorgeous photography Clara! Did you take the drone up as well?")
        )

        repository.insertComment(
            VideoComment(videoId = v4, authorName = "Mom", authorRole = "Aunt", content = "This works so well! The stop motion was incredibly cute. Good job Tommy!")
        )
    }

    // Navigation & Backstack Management
    fun selectTab(tab: AppScreen) {
        _currentScreen.value = tab
        _playingVideoId.value = null
        screenBackstack.clear()
    }

    fun navigateTo(screen: AppScreen) {
        screenBackstack.add(_currentScreen.value)
        _currentScreen.value = screen
        if (screen is AppScreen.VideoPlayer) {
            _playingVideoId.value = screen.videoId
            viewModelScope.launch {
                repository.incrementViews(screen.videoId)
            }
        }
    }

    fun navigateBack(): Boolean {
        if (screenBackstack.isNotEmpty()) {
            val prev = screenBackstack.removeAt(screenBackstack.size - 1)
            _currentScreen.value = prev
            if (prev is AppScreen.VideoPlayer) {
                _playingVideoId.value = prev.videoId
            } else {
                _playingVideoId.value = null
            }
            return true
        }
        _currentScreen.value = AppScreen.Home
        _playingVideoId.value = null
        return false
    }

    // Filtering Home Screen videos
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    // Interacting with a video
    fun addLike(videoId: Long) {
        viewModelScope.launch {
            repository.incrementLikes(videoId)
        }
    }

    fun postComment(videoId: Long, authorName: String, authorRole: String, content: String) {
        if (content.isBlank() || authorName.isBlank()) return
        viewModelScope.launch {
            repository.insertComment(
                VideoComment(
                    videoId = videoId,
                    authorName = authorName,
                    authorRole = authorRole,
                    content = content
                )
            )
        }
    }

    // Create a new family channel
    fun createChannel(name: String, handle: String, description: String, avatarColorOrdinal: Int) {
        if (name.isBlank() || handle.isBlank()) return
        viewModelScope.launch {
            repository.insertChannel(
                FamilyChannel(
                    name = name,
                    handle = if (handle.startsWith("@")) handle else "@$handle",
                    description = description,
                    avatarColorOrdinal = avatarColorOrdinal,
                    bannerPresetOrdinal = (0..4).random(),
                    subCount = 1
                )
            )
            // Go to channels page so they see it!
            selectTab(AppScreen.Channels)
        }
    }

    // Add a brand new family video
    fun uploadVideo(
        channelId: Long,
        title: String,
        description: String,
        duration: String,
        category: String,
        thumbnailPresetOrdinal: Int
    ) {
        if (title.isBlank() || description.isBlank()) return
        viewModelScope.launch {
            val mockVideoUrl = "https://example.com/videos/${title.replace(" ", "_").lowercase()}.mp4"
            repository.insertVideo(
                FamilyVideo(
                    channelId = channelId,
                    title = title,
                    description = description,
                    videoUrl = mockVideoUrl,
                    thumbnailPresetOrdinal = thumbnailPresetOrdinal,
                    duration = if (duration.isBlank()) "04:15" else duration,
                    views = 1,
                    likes = 1,
                    timestamp = System.currentTimeMillis(),
                    category = category
                )
            )
            // Go back to home feed so they see their shared masterpiece!
            selectTab(AppScreen.Home)
        }
    }

    // Filtered Video Stream Helper for Channel Details
    fun getVideosForChannel(channelId: Long): StateFlow<List<VideoWithChannel>> {
        return repository.getVideosByChannel(channelId).stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    // Live Flow stream of specific channel properties
    fun getChannelFlow(channelId: Long): StateFlow<FamilyChannel?> {
        return repository.getChannelById(channelId).stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )
    }
}
