package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Elements - Re-mapped for Elegant Dark experience
val PrimaryRed = Color(0xFFD1E4FF) // Elegant pale blue accent
val SecondaryRose = Color(0xFFC2C7CF)
val AccentAmber = Color(0xFFD1E4FF)

val CozyBackgroundLight = Color(0xFF1A1C1E) // Elegant dark slate background
val CozySurfaceLight = Color(0xFF2F3033) // Elegant slate gray card surface
val TextDarkField = Color(0xFFE2E2E6) // Light elegant text color

// Dark Theme (Cinema Mode) Elements
val PrimaryRedDark = Color(0xFFD1E4FF)
val DarkBackground = Color(0xFF1A1C1E)
val DarkSurface = Color(0xFF2F3033)
val TextLightField = Color(0xFFE2E2E6)

// Elegant Dark Design Theme Specific Colors
val ElegantDarkBorder = Color(0xFF43474E)
val ElegantDarkPillActive = Color(0xFF374955)
val ElegantDarkSecondaryText = Color(0xFFC2C7CF)

// Avatars Colors for family members - polished to fit within dark elegant theme
val AvatarOrange = Color(0xFFE08D46)
val AvatarPink = Color(0xFFD95C88)
val AvatarTeal = Color(0xFF4DB6AC)
val AvatarGreen = Color(0xFF81C784)
val AvatarIndigo = Color(0xFF7986CB)

val BannerPreset1 = Color(0xFF2F3033)
val BannerPreset2 = Color(0xFF374955)
val BannerPreset3 = Color(0xFF43474E)
val BannerPreset4 = Color(0xFF2F3033)
val BannerPreset5 = Color(0xFF374955)
