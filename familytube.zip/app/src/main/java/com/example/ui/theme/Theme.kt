package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryRedDark,
    secondary = SecondaryRose,
    tertiary = AccentAmber,
    background = DarkBackground,
    surface = DarkSurface,
    onPrimary = Color(0xFF001D36),
    onSecondary = Color(0xFF1A1C1E),
    onTertiary = Color(0xFF1A1C1E),
    onBackground = TextLightField,
    onSurface = TextLightField,
    surfaceVariant = ElegantDarkPillActive,
    onSurfaceVariant = TextLightField,
    outline = ElegantDarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryRed,
    secondary = SecondaryRose,
    tertiary = AccentAmber,
    background = CozyBackgroundLight,
    surface = CozySurfaceLight,
    onPrimary = Color(0xFF001D36),
    onSecondary = Color(0xFF1A1C1E),
    onTertiary = Color(0xFF1A1C1E),
    onBackground = TextDarkField,
    onSurface = TextDarkField,
    surfaceVariant = ElegantDarkPillActive,
    onSurfaceVariant = TextDarkField,
    outline = ElegantDarkBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    // Both themes utilize the gorgeous Elegant Dark experience for consistent aesthetic
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
